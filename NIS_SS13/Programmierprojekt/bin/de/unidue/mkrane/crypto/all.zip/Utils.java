package de.unidue.mkrane.crypto;

import java.util.Random;

class Utils {

	private static Random r = new Random();

	public static int randomInt(int min, int max) {
		return min + r.nextInt(max - min);
	}

	public static final String[][] HexBinLookUp = {
			{ "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "a", "b", "c",
					"d", "e", "f" },
			{ "0000", "0001", "0010", "0011", "0100", "0101", "0110", "0111",
					"1000", "1001", "1010", "1011", "1100", "1101", "1110",
					"1111" } };

	public static final String[][] ASCII = new String[][] {
			{ "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C",
					"D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O",
					"P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "a",
					"b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m",
					"n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y",
					"z" },
			{ "110000", "110001", "110010", "110011", "110100", "110101",
					"110110", "110111", "111000", "111001", "1000001",
					"1000010", "1000011", "1000100", "1000101", "1000110",
					"1000111", "1001000", "1001001", "1001010", "1001011",
					"1001100", "1001101", "1001110", "1001111", "1010000",
					"1010001", "1010010", "1010011", "1010100", "1010101",
					"1010110", "1010111", "1011000", "1011111", "1100000",
					"1100001", "1100010", "1100011", "1100100", "1100101",
					"1100110", "1100111", "1101000", "1101001", "1101010",
					"1101011", "1101100", "1101101", "1101110", "1101111",
					"1110000", "1110001", "1110010", "1110011", "1110100",
					"1110101", "1110110", "1110111", "1111000", "1111001",
					"1111010" } };

	public static String CharToBin(char c) {
		for (int i = 0; i < ASCII[0].length; i++) {
			if (ASCII[0][i].charAt(0) == c)
				return Utils.paddTo(ASCII[1][i], 8);
		}
		return "";
	}

	public static char BinToChar(String c) {
		for (int i = 0; i < ASCII[0].length; i++) {
			if (ASCII[1][i].equals(c))
				return ASCII[0][i].charAt(0);
		}
		return ' ';
	}

	public static int CharToDez(char c) {
		return BinToDez(CharToBin(c));
	}

	public static char DezToChar(int c) {
		return BinToChar(DezToBin(c));
	}

	public static String HexToBin(String a) {
		String result = "";
		for (int i = 0; i < a.length(); i++) {
			for (int j = 0; j < HexBinLookUp[0].length; j++) {
				if ((a.charAt(i) + "").equals(HexBinLookUp[0][j])) {
					result += HexBinLookUp[1][j];
				}
			}
		}
		return result;
	}

	public static String BinToHex(String a) {
		String[] tmp = Utils.splitIntoChunksOf(a, 4);

		String result = "";
		for (int i = 0; i < tmp.length; i++) {
			result += HexBinLookUp[0][BinToDez(tmp[i])];
		}
		return result;
	}

	public static String DezToBin(int a) {
		return DezToBin(a, 0);
	}

	public static String DezToBin(int a, int padding) {
		String result = "";

		while (a > 0) {
			result = (Modulo(a, 2) == 0 ? "0" : "1") + result;
			a /= 2;
		}
		return paddTo(result, padding);
	}

	public static int BinToDez(String s) {
		int result = 0;
		for (int i = 0; i < s.length(); i++) {
			if (s.charAt(i) == '1')
				result += Math.pow(2, s.length() - 1 - i);
		}
		return result;
	}

	public static int HexToDez(String a) {
		return BinToDez(HexToBin(a));
	}

	public static String DezToHex(int a) {
		return BinToHex(DezToBin(a, 0));
	}

	public static int[] StringToIntArray(String text, String c) {
		String[] strings = text.split(c);

		int[] result = new int[strings.length];
		for (int i = 0; i < result.length; i++)
			result[i] = Integer.parseInt(strings[i]);

		return result;
	}

	public static String IntArrayToString(int[] array) {
		return IntArrayToString(array, "");
	}

	public static String IntArrayToString(int[] array, String c) {
		StringBuilder result = new StringBuilder();
		result.append(array[0]);

		for (int i = 1; i < array.length; i++) {
			result.append(c + array[i]);
		}
		return result.toString();
	}

	public static String paddTo(String a, int length) {
		if (a.length() == length)
			return a;
		if (a.length() > length)
			a = removePadding(a);

		return addPadding(a, length);
	}

	private static String addPadding(String a, int padding) {
		while (a.length() < padding)
			a = "0" + a;
		return a;
	}

	public static String removePadding(String a) {
		if (a.length() <= 1)
			return a;
		while (a.length() > 0 && a.charAt(0) == '0')
			a = a.substring(1);

		return a;
	}

	public static String[] splitIntoChunksOf(String a, int size) {
		while (Utils.Modulo(a.length(), size) != 0) {
			a = "0" + a;
		}

		String[] result = new String[a.length() / size];
		for (int i = 0; i < result.length; i++) {
			result[i] = a.substring(0 + i * size, size + i * size);
		}

		return result;
	}

	public static String XOR(String a, String b) {
		while (a.length() > b.length())
			b = "0" + b;
		while (a.length() < b.length())
			a = "0" + a;
		String result = "";
		for (int i = 0; i < a.length(); i++) {
			if (a.charAt(i) == b.charAt(i))
				result += "0";
			else
				result += "1";
		}
		return result;
	}

	public static int Modulo(int a, int b) {
		while (a < 0)
			a += b;
		while (a >= b)
			a -= b;

		return a;
	}

	public static int powerModulo(int a, int b, int c) {
		int result = 1;

		for (int i = 0; i < b; i++) {
			result *= a;
			result = Modulo(result, c);
		}
		return result;
	}

	public static String Modulo(String a, String b) {
		if (a.length() > b.length())
			b = addPadding(b, a.length());
		else
			a = addPadding(a, b.length());

		String result = "";
		for (int i = 0; i < a.length(); i++) {
			if (a.charAt(i) == b.charAt(i))
				result += "1";
			else
				result += "0";
		}

		result = paddTo(result, 8);
		return result;
	}

	public static String Faktor(int a) {
		String result = "";
		int max = (int) Math.sqrt(a);

		for (int i = 2; i < max; i++) {
			if (Modulo(a, i) == 0) {
				a /= i;
				result += i + ",";
				i = 1;
			}
		}
		if (a != 1)
			result += a;
		return result;
	}

	public static int[] GetPrimes(int max) {
		boolean[] notPrime = new boolean[max + 1];
		int n = max - 1;

		for (int i = 2; i < notPrime.length; i++) {
			if (notPrime[i])
				continue;
			for (int j = i + 1; j < notPrime.length; j++) {
				if (notPrime[j])
					continue;
				if (Modulo(j, i) == 0) {
					notPrime[j] = true;
					n--;
				}
			}
		}
		int[] result = new int[n];
		int pos = 0;
		for (int i = 2; i <= max; i++) {
			if (!notPrime[i]) {
				result[pos++] = i;
			}
		}
		return result;
	}
}